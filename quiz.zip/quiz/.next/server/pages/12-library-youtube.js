"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/12-library-youtube";
exports.ids = ["pages/12-library-youtube"];
exports.modules = {

/***/ "./pages/12-library-youtube/index.tsx":
/*!********************************************!*\
  !*** ./pages/12-library-youtube/index.tsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LibraryYoutubePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_player__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-player */ \"react-player\");\n/* harmony import */ var react_player__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_player__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction LibraryYoutubePage() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_player__WEBPACK_IMPORTED_MODULE_1___default()), {\n        url: \"https://www.youtube.com/watch?v=ysz5S6PUM-U\",\n        width: 800,\n        height: 600,\n        playing: true,\n        muted: true\n    }, void 0, false, {\n        fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/12-library-youtube/index.tsx\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xMi1saWJyYXJ5LXlvdXR1YmUvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFzQztBQUV2QixRQUFRLENBQUNDLGtCQUFrQixHQUFHLENBQUM7SUFDNUMsTUFBTSw2RUFDSEQscURBQVc7UUFDVkUsR0FBRyxFQUFDLENBQTZDO1FBQ2pEQyxLQUFLLEVBQUUsR0FBRztRQUNWQyxNQUFNLEVBQUUsR0FBRztRQUNYQyxPQUFPLEVBQUUsSUFBSTtRQUNiQyxLQUFLLEVBQUUsSUFBSTs7Ozs7O0FBR2pCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcmVlYm9hcmRfZnJvbnRlbmQvLi9wYWdlcy8xMi1saWJyYXJ5LXlvdXR1YmUvaW5kZXgudHN4PzlmYmQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0UGxheWVyIGZyb20gXCJyZWFjdC1wbGF5ZXJcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGlicmFyeVlvdXR1YmVQYWdlKCkge1xuICByZXR1cm4gKFxuICAgIDxSZWFjdFBsYXllclxuICAgICAgdXJsPVwiaHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj15c3o1UzZQVU0tVVwiXG4gICAgICB3aWR0aD17ODAwfVxuICAgICAgaGVpZ2h0PXs2MDB9XG4gICAgICBwbGF5aW5nPXt0cnVlfVxuICAgICAgbXV0ZWQ9e3RydWV9XG4gICAgLz5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJSZWFjdFBsYXllciIsIkxpYnJhcnlZb3V0dWJlUGFnZSIsInVybCIsIndpZHRoIiwiaGVpZ2h0IiwicGxheWluZyIsIm11dGVkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/12-library-youtube/index.tsx\n");

/***/ }),

/***/ "react-player":
/*!*******************************!*\
  !*** external "react-player" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("react-player");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/12-library-youtube/index.tsx"));
module.exports = __webpack_exports__;

})();