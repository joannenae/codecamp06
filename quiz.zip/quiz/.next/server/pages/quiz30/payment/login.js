"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/quiz30/payment/login";
exports.ids = ["pages/quiz30/payment/login"];
exports.modules = {

/***/ "./pages/quiz30/payment/login/index.tsx":
/*!**********************************************!*\
  !*** ./pages/quiz30/payment/login/index.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction LoginPage() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const { 0: password , 1: setPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const onChangeEmail = (event)=>{\n        setEmail(event.target.value);\n    };\n    const onChangePassword = (event)=>{\n        setPassword(event.target.value);\n    };\n    const onClickLogin = ()=>{\n        if (email !== \"\" && password !== \"\") {\n            alert(\"충전하는 페이지로 이동하시겠습니까?\");\n            router.push(\"/quiz30/payment/loading\");\n        }\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            \"이메일: \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"text\",\n                onChange: onChangeEmail\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/quiz30/payment/login/index.tsx\",\n                lineNumber: 25,\n                columnNumber: 12\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/quiz30/payment/login/index.tsx\",\n                lineNumber: 26,\n                columnNumber: 7\n            }, this),\n            \"비밀번호: \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                onChange: onChangePassword\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/quiz30/payment/login/index.tsx\",\n                lineNumber: 27,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/quiz30/payment/login/index.tsx\",\n                lineNumber: 28,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickLogin,\n                children: \"로그인\"\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/quiz30/payment/login/index.tsx\",\n                lineNumber: 29,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/quiz30/payment/login/index.tsx\",\n        lineNumber: 24,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9xdWl6MzAvcGF5bWVudC9sb2dpbi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBdUM7QUFDUDtBQUVqQixRQUFRLENBQUNFLFNBQVMsR0FBRyxDQUFDO0lBQ25DLEtBQUssQ0FBQ0MsTUFBTSxHQUFHSCxzREFBUztJQUV4QixLQUFLLE1BQUVJLEtBQUssTUFBRUMsUUFBUSxNQUFJSiwrQ0FBUSxDQUFDLENBQUU7SUFDckMsS0FBSyxNQUFFSyxRQUFRLE1BQUVDLFdBQVcsTUFBSU4sK0NBQVEsQ0FBQyxDQUFFO0lBRTNDLEtBQUssQ0FBQ08sYUFBYSxJQUFJQyxLQUFVLEdBQUssQ0FBQztRQUNyQ0osUUFBUSxDQUFDSSxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztJQUM3QixDQUFDO0lBQ0QsS0FBSyxDQUFDQyxnQkFBZ0IsSUFBSUgsS0FBVSxHQUFLLENBQUM7UUFDeENGLFdBQVcsQ0FBQ0UsS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUs7SUFDaEMsQ0FBQztJQUNELEtBQUssQ0FBQ0UsWUFBWSxPQUFTLENBQUM7UUFDMUIsRUFBRSxFQUFFVCxLQUFLLEtBQUssQ0FBRSxLQUFJRSxRQUFRLEtBQUssQ0FBRSxHQUFFLENBQUM7WUFDcENRLEtBQUssQ0FBQyxDQUFxQjtZQUNLWCxNQUExQixDQUFDWSxJQUFJLENBQUMsQ0FBeUI7UUFDdkMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLDZFQUNIQyxDQUFHOztZQUFDLENBQ0U7d0ZBQU9DLENBQUs7Z0JBQUNDLElBQUksRUFBQyxDQUFNO2dCQUFDQyxRQUFRLEVBQUVYLGFBQWE7Ozs7Ozt3RkFDOUNZLENBQUo7Ozs7O1lBQUcsQ0FDQTt3RkFBU0gsQ0FBSztnQkFBQ0MsSUFBSSxFQUFDLENBQVU7Z0JBQUNDLFFBQVEsRUFBRVAsZ0JBQWdCOzs7Ozs7d0ZBQ3REUSxDQUFOOzs7Ozt3RkFDRkMsQ0FBTTtnQkFBQ0MsT0FBTyxFQUFFVCxZQUFZOzBCQUFFLENBQUc7Ozs7Ozs7Ozs7OztBQUd4QyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJlZWJvYXJkX2Zyb250ZW5kLy4vcGFnZXMvcXVpejMwL3BheW1lbnQvbG9naW4vaW5kZXgudHN4PzQyNWYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2dpblBhZ2UoKSB7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3Qgb25DaGFuZ2VFbWFpbCA9IChldmVudDogYW55KSA9PiB7XG4gICAgc2V0RW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgfTtcbiAgY29uc3Qgb25DaGFuZ2VQYXNzd29yZCA9IChldmVudDogYW55KSA9PiB7XG4gICAgc2V0UGFzc3dvcmQoZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgfTtcbiAgY29uc3Qgb25DbGlja0xvZ2luID0gKCkgPT4ge1xuICAgIGlmIChlbWFpbCAhPT0gXCJcIiAmJiBwYXNzd29yZCAhPT0gXCJcIikge1xuICAgICAgYWxlcnQoXCLstqnsoITtlZjripQg7Y6Y7J207KeA66GcIOydtOuPme2VmOyLnOqyoOyKteuLiOq5jD9cIik7XG4gICAgICByb3V0ZXIucHVzaChcIi9xdWl6MzAvcGF5bWVudC9sb2FkaW5nXCIpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICDsnbTrqZTsnbw6IDxpbnB1dCB0eXBlPVwidGV4dFwiIG9uQ2hhbmdlPXtvbkNoYW5nZUVtYWlsfSAvPlxuICAgICAgPGJyIC8+XG4gICAgICDruYTrsIDrsojtmLg6IDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBvbkNoYW5nZT17b25DaGFuZ2VQYXNzd29yZH0gLz5cbiAgICAgIDxiciAvPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrTG9naW59PuuhnOq3uOyduDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm5hbWVzIjpbInVzZVJvdXRlciIsInVzZVN0YXRlIiwiTG9naW5QYWdlIiwicm91dGVyIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJvbkNoYW5nZUVtYWlsIiwiZXZlbnQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm9uQ2hhbmdlUGFzc3dvcmQiLCJvbkNsaWNrTG9naW4iLCJhbGVydCIsInB1c2giLCJkaXYiLCJpbnB1dCIsInR5cGUiLCJvbkNoYW5nZSIsImJyIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/quiz30/payment/login/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/quiz30/payment/login/index.tsx"));
module.exports = __webpack_exports__;

})();