"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/16-state";
exports.ids = ["pages/16-state"];
exports.modules = {

/***/ "./pages/16-state/index.tsx":
/*!**********************************!*\
  !*** ./pages/16-state/index.tsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ PrevstatePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction PrevstatePage() {\n    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);\n    function sumAll() {\n        setState((prev)=>prev + 1\n        );\n        setState((prev)=>prev + 2\n        );\n        setState((prev)=>prev + 3\n        );\n        setState((prev)=>prev + 4\n        );\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"결과는: \",\n                    state\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/16-state/index.tsx\",\n                lineNumber: 15,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: sumAll,\n                children: \"실행!\"\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/16-state/index.tsx\",\n                lineNumber: 16,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNi1zdGF0ZS9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQWdDO0FBRWpCLFFBQVEsQ0FBQ0MsYUFBYSxHQUFHLENBQUM7SUFDdkMsS0FBSyxNQUFFQyxLQUFLLE1BQUVDLFFBQVEsTUFBSUgsK0NBQVEsQ0FBQyxDQUFDO2FBRTNCSSxNQUFNLEdBQUcsQ0FBQztRQUNqQkQsUUFBUSxFQUFFRSxJQUFJLEdBQUtBLElBQUksR0FBRyxDQUFDOztRQUMzQkYsUUFBUSxFQUFFRSxJQUFJLEdBQUtBLElBQUksR0FBRyxDQUFDOztRQUMzQkYsUUFBUSxFQUFFRSxJQUFJLEdBQUtBLElBQUksR0FBRyxDQUFDOztRQUMzQkYsUUFBUSxFQUFFRSxJQUFJLEdBQUtBLElBQUksR0FBRyxDQUFDOztJQUM3QixDQUFDO0lBRUQsTUFBTTs7d0ZBRURDLENBQUc7O29CQUFDLENBQUs7b0JBQU9KLEtBQUs7Ozs7Ozs7d0ZBQ2ZLLENBQUE7Z0JBQUNDLE9BQU8sRUFBRUosTUFBTTswQkFBRSxDQUFHOzs7Ozs7OztBQUdsQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJlZWJvYXJkX2Zyb250ZW5kLy4vcGFnZXMvMTYtc3RhdGUvaW5kZXgudHN4P2Q3MDIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJldnN0YXRlUGFnZSgpIHtcbiAgY29uc3QgW3N0YXRlLCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZSgwKTtcblxuICBmdW5jdGlvbiBzdW1BbGwoKSB7XG4gICAgc2V0U3RhdGUoKHByZXYpID0+IHByZXYgKyAxKTtcbiAgICBzZXRTdGF0ZSgocHJldikgPT4gcHJldiArIDIpO1xuICAgIHNldFN0YXRlKChwcmV2KSA9PiBwcmV2ICsgMyk7XG4gICAgc2V0U3RhdGUoKHByZXYpID0+IHByZXYgKyA0KTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxkaXY+6rKw6rO864qUOiB7c3RhdGV9PC9kaXY+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e3N1bUFsbH0+7Iuk7ZaJITwvYnV0dG9uPlxuICAgIDwvPlxuICApO1xufVxuIl0sIm5hbWVzIjpbInVzZVN0YXRlIiwiUHJldnN0YXRlUGFnZSIsInN0YXRlIiwic2V0U3RhdGUiLCJzdW1BbGwiLCJwcmV2IiwiZGl2IiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/16-state/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/16-state/index.tsx"));
module.exports = __webpack_exports__;

})();