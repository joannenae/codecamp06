"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/27-01-login";
exports.ids = ["pages/27-01-login"];
exports.modules = {

/***/ "./pages/27-01-login/index.tsx":
/*!*************************************!*\
  !*** ./pages/27-01-login/index.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../src/commons/store */ \"./src/commons/store/index.ts\");\n\n\n\n\n\n\nconst LOGIN_USER = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  mutation loginUser($email: String!, $password: String!) {\n    loginUser(email: $email, password: $password) {\n      accessToken\n    }\n  }\n`;\nfunction LoginPage() {\n    const [, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_5__.accessTokenState);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const { 0: password , 1: setPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const [loginUser] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useMutation)(LOGIN_USER);\n    const onChangeEmail = (event)=>{\n        setEmail(event.target.value);\n    };\n    const onChangePassword = (event)=>{\n        setPassword(event.target.value);\n    };\n    const onClickLogin = async ()=>{\n        const result = await loginUser({\n            variables: {\n                email: email,\n                password: password\n            }\n        });\n        const accessToken = result.data.loginUser.accessToken;\n        setAccessToken(accessToken);\n        console.log(accessToken);\n        alert(\"로그인 되었습니다\");\n        router.push(\"/27-02-login-success\");\n        if (result.data.loginUser.accessToken !== accessToken) {\n            console.log(accessToken);\n            router.push(\"/27-01-login\");\n            alert(\"로그인을 먼저 해주세요\");\n        }\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            \"이메일: \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"text\",\n                onChange: onChangeEmail\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/27-01-login/index.tsx\",\n                lineNumber: 50,\n                columnNumber: 12\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/27-01-login/index.tsx\",\n                lineNumber: 51,\n                columnNumber: 7\n            }, this),\n            \"비밀번호: \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                onChange: onChangePassword\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/27-01-login/index.tsx\",\n                lineNumber: 52,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/27-01-login/index.tsx\",\n                lineNumber: 53,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickLogin,\n                children: \"로그인\"\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/27-01-login/index.tsx\",\n                lineNumber: 54,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/27-01-login/index.tsx\",\n        lineNumber: 49,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yNy0wMS1sb2dpbi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFpRDtBQUNWO0FBQ1A7QUFDTztBQUNtQjtBQUUxRCxLQUFLLENBQUNNLFVBQVUsR0FBR0wsK0NBQUcsQ0FBQzs7Ozs7O0FBTXZCO0FBRWUsUUFBUSxDQUFDTSxTQUFTLEdBQUcsQ0FBQztJQUNuQyxLQUFLLElBQUlDLGNBQWMsSUFBSUosc0RBQWMsQ0FBQ0MsZ0VBQWdCO0lBQzFELEtBQUssQ0FBQ0ksTUFBTSxHQUFHUCxzREFBUztJQUV4QixLQUFLLE1BQUVRLEtBQUssTUFBRUMsUUFBUSxNQUFJUiwrQ0FBUSxDQUFDLENBQUU7SUFDckMsS0FBSyxNQUFFUyxRQUFRLE1BQUVDLFdBQVcsTUFBSVYsK0NBQVEsQ0FBQyxDQUFFO0lBQzNDLEtBQUssRUFBRVcsU0FBUyxJQUFJZCwyREFBVyxDQUFDTSxVQUFVO0lBRTFDLEtBQUssQ0FBQ1MsYUFBYSxJQUFJQyxLQUFVLEdBQUssQ0FBQztRQUNyQ0wsUUFBUSxDQUFDSyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztJQUM3QixDQUFDO0lBQ0QsS0FBSyxDQUFDQyxnQkFBZ0IsSUFBSUgsS0FBVSxHQUFLLENBQUM7UUFDeENILFdBQVcsQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUs7SUFDaEMsQ0FBQztJQUNELEtBQUssQ0FBQ0UsWUFBWSxhQUFlLENBQUM7UUFDaEMsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDUCxTQUFTLENBQUMsQ0FBQztZQUM5QlEsU0FBUyxFQUFFLENBQUM7Z0JBQ1ZaLEtBQUssRUFBRUEsS0FBSztnQkFDWkUsUUFBUSxFQUFFQSxRQUFRO1lBQ3BCLENBQUM7UUFDSCxDQUFDO1FBQ0QsS0FBSyxDQUFDVyxXQUFXLEdBQUdGLE1BQU0sQ0FBQ0csSUFBSSxDQUFDVixTQUFTLENBQUNTLFdBQVc7UUFDckRmLGNBQWMsQ0FBQ2UsV0FBVztRQUMxQkUsT0FBTyxDQUFDQyxHQUFHLENBQUNILFdBQVc7UUFDdkJJLEtBQUssQ0FBQyxDQUFXO1FBQ0RsQixNQUFWLENBQUNtQixJQUFJLENBQUMsQ0FBc0I7UUFDbEMsRUFBRSxFQUFFUCxNQUFNLENBQUNHLElBQUksQ0FBQ1YsU0FBUyxDQUFDUyxXQUFXLEtBQUtBLFdBQVcsRUFBRSxDQUFDO1lBQ3RERSxPQUFPLENBQUNDLEdBQUcsQ0FBQ0gsV0FBVztZQUN2QmQsTUFBTSxDQUFDbUIsSUFBSSxDQUFDLENBQWM7WUFDMUJELEtBQUssQ0FBQyxDQUFjO1FBQ0YsQ0FBbkI7SUFDSCxDQUFDO0lBRUQsTUFBTSw2RUFDSEUsQ0FBRzs7WUFBQyxDQUNFO3dGQUFPQyxDQUFLO2dCQUFDQyxJQUFJLEVBQUMsQ0FBTTtnQkFBQ0MsUUFBUSxFQUFFakIsYUFBYTs7Ozs7O3dGQUM5Q2tCLENBQUo7Ozs7O1lBQUcsQ0FDQTt3RkFBU0gsQ0FBSztnQkFBQ0MsSUFBSSxFQUFDLENBQVU7Z0JBQUNDLFFBQVEsRUFBRWIsZ0JBQWdCOzs7Ozs7d0ZBQ3REYyxDQUFOOzs7Ozt3RkFDRkMsQ0FBTTtnQkFBQ0MsT0FBTyxFQUFFZixZQUFZOzBCQUFFLENBQUc7Ozs7Ozs7Ozs7OztBQUd4QyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJlZWJvYXJkX2Zyb250ZW5kLy4vcGFnZXMvMjctMDEtbG9naW4vaW5kZXgudHN4PzVjYTMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24sIGdxbCB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlUmVjb2lsU3RhdGUgfSBmcm9tIFwicmVjb2lsXCI7XG5pbXBvcnQgeyBhY2Nlc3NUb2tlblN0YXRlIH0gZnJvbSBcIi4uLy4uL3NyYy9jb21tb25zL3N0b3JlXCI7XG5cbmNvbnN0IExPR0lOX1VTRVIgPSBncWxgXG4gIG11dGF0aW9uIGxvZ2luVXNlcigkZW1haWw6IFN0cmluZyEsICRwYXNzd29yZDogU3RyaW5nISkge1xuICAgIGxvZ2luVXNlcihlbWFpbDogJGVtYWlsLCBwYXNzd29yZDogJHBhc3N3b3JkKSB7XG4gICAgICBhY2Nlc3NUb2tlblxuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTG9naW5QYWdlKCkge1xuICBjb25zdCBbLCBzZXRBY2Nlc3NUb2tlbl0gPSB1c2VSZWNvaWxTdGF0ZShhY2Nlc3NUb2tlblN0YXRlKTtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2xvZ2luVXNlcl0gPSB1c2VNdXRhdGlvbihMT0dJTl9VU0VSKTtcblxuICBjb25zdCBvbkNoYW5nZUVtYWlsID0gKGV2ZW50OiBhbnkpID0+IHtcbiAgICBzZXRFbWFpbChldmVudC50YXJnZXQudmFsdWUpO1xuICB9O1xuICBjb25zdCBvbkNoYW5nZVBhc3N3b3JkID0gKGV2ZW50OiBhbnkpID0+IHtcbiAgICBzZXRQYXNzd29yZChldmVudC50YXJnZXQudmFsdWUpO1xuICB9O1xuICBjb25zdCBvbkNsaWNrTG9naW4gPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgbG9naW5Vc2VyKHtcbiAgICAgIHZhcmlhYmxlczoge1xuICAgICAgICBlbWFpbDogZW1haWwsXG4gICAgICAgIHBhc3N3b3JkOiBwYXNzd29yZCxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSByZXN1bHQuZGF0YS5sb2dpblVzZXIuYWNjZXNzVG9rZW47XG4gICAgc2V0QWNjZXNzVG9rZW4oYWNjZXNzVG9rZW4pO1xuICAgIGNvbnNvbGUubG9nKGFjY2Vzc1Rva2VuKTtcbiAgICBhbGVydChcIuuhnOq3uOyduCDrkJjsl4jsirXri4jri6RcIik7XG4gICAgcm91dGVyLnB1c2goXCIvMjctMDItbG9naW4tc3VjY2Vzc1wiKTtcbiAgICBpZiAocmVzdWx0LmRhdGEubG9naW5Vc2VyLmFjY2Vzc1Rva2VuICE9PSBhY2Nlc3NUb2tlbikge1xuICAgICAgY29uc29sZS5sb2coYWNjZXNzVG9rZW4pO1xuICAgICAgcm91dGVyLnB1c2goXCIvMjctMDEtbG9naW5cIik7XG4gICAgICBhbGVydChcIuuhnOq3uOyduOydhCDrqLzsoIAg7ZW07KO87IS47JqUXCIpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICDsnbTrqZTsnbw6IDxpbnB1dCB0eXBlPVwidGV4dFwiIG9uQ2hhbmdlPXtvbkNoYW5nZUVtYWlsfSAvPlxuICAgICAgPGJyIC8+XG4gICAgICDruYTrsIDrsojtmLg6IDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBvbkNoYW5nZT17b25DaGFuZ2VQYXNzd29yZH0gLz5cbiAgICAgIDxiciAvPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrTG9naW59PuuhnOq3uOyduDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm5hbWVzIjpbInVzZU11dGF0aW9uIiwiZ3FsIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJ1c2VSZWNvaWxTdGF0ZSIsImFjY2Vzc1Rva2VuU3RhdGUiLCJMT0dJTl9VU0VSIiwiTG9naW5QYWdlIiwic2V0QWNjZXNzVG9rZW4iLCJyb3V0ZXIiLCJlbWFpbCIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImxvZ2luVXNlciIsIm9uQ2hhbmdlRW1haWwiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwib25DaGFuZ2VQYXNzd29yZCIsIm9uQ2xpY2tMb2dpbiIsInJlc3VsdCIsInZhcmlhYmxlcyIsImFjY2Vzc1Rva2VuIiwiZGF0YSIsImNvbnNvbGUiLCJsb2ciLCJhbGVydCIsInB1c2giLCJkaXYiLCJpbnB1dCIsInR5cGUiLCJvbkNoYW5nZSIsImJyIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/27-01-login/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\n// 글로벌 스테이트\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"isEditState\",\n    default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"iaccessTokenState\",\n    default: \"\"\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQTZCO0FBRTdCLEVBQVc7QUFDSixLQUFLLENBQUNDLFdBQVcsR0FBR0QsNENBQUksQ0FBQyxDQUFDO0lBQy9CRSxHQUFHLEVBQUUsQ0FBYTtJQUNsQkMsT0FBTyxFQUFFLEtBQUs7QUFDaEIsQ0FBQztBQUNNLEtBQUssQ0FBQ0MsZ0JBQWdCLEdBQUdKLDRDQUFJLENBQUMsQ0FBQztJQUNwQ0UsR0FBRyxFQUFFLENBQW1CO0lBQ3hCQyxPQUFPLEVBQUUsQ0FBRTtBQUNiLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcmVlYm9hcmRfZnJvbnRlbmQvLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cz8zY2JmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20gfSBmcm9tIFwicmVjb2lsXCI7XG5cbi8vIOq4gOuhnOuyjCDsiqTthYzsnbTtirhcbmV4cG9ydCBjb25zdCBpc0VkaXRTdGF0ZSA9IGF0b20oe1xuICBrZXk6IFwiaXNFZGl0U3RhdGVcIixcbiAgZGVmYXVsdDogZmFsc2UsXG59KTtcbmV4cG9ydCBjb25zdCBhY2Nlc3NUb2tlblN0YXRlID0gYXRvbSh7XG4gIGtleTogXCJpYWNjZXNzVG9rZW5TdGF0ZVwiLFxuICBkZWZhdWx0OiBcIlwiLFxufSk7XG4iXSwibmFtZXMiOlsiYXRvbSIsImlzRWRpdFN0YXRlIiwia2V5IiwiZGVmYXVsdCIsImFjY2Vzc1Rva2VuU3RhdGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/27-01-login/index.tsx"));
module.exports = __webpack_exports__;

})();