"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/15-modal-address";
exports.ids = ["pages/15-modal-address"];
exports.modules = {

/***/ "./pages/15-modal-address/index.tsx":
/*!******************************************!*\
  !*** ./pages/15-modal-address/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ModalCustomPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ \"antd\");\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react_daum_postcode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-daum-postcode */ \"react-daum-postcode\");\n/* harmony import */ var react_daum_postcode__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_daum_postcode__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nfunction ModalCustomPage() {\n    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const { 0: data1 , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const showModal = ()=>{\n        setIsOpen(true);\n    };\n    const handleOk = ()=>{\n        setIsOpen(false);\n    };\n    const handleCancel = ()=>{\n        setIsOpen(false);\n    };\n    const handleComplete = (data)=>{\n        console.log(data);\n        setIsOpen(false);\n        setData(data);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__.Button, {\n                type: \"primary\",\n                onClick: showModal,\n                children: \"모달열기\"\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/15-modal-address/index.tsx\",\n                lineNumber: 29,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: data1.address\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/15-modal-address/index.tsx\",\n                lineNumber: 32,\n                columnNumber: 7\n            }, this),\n            isOpen && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__.Modal, {\n                title: \"Basic Modal\",\n                visible: true,\n                onOk: handleOk,\n                onCancel: handleCancel,\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_daum_postcode__WEBPACK_IMPORTED_MODULE_3___default()), {\n                    onComplete: handleComplete\n                }, void 0, false, {\n                    fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/15-modal-address/index.tsx\",\n                    lineNumber: 41,\n                    columnNumber: 11\n                }, this)\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/15-modal-address/index.tsx\",\n                lineNumber: 35,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNS1tb2RhbC1hZGRyZXNzL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQWdDO0FBQ0k7QUFDVTtBQUUvQixRQUFRLENBQUNJLGVBQWUsR0FBRyxDQUFDO0lBQ3pDLEtBQUssTUFBRUMsTUFBTSxNQUFFQyxTQUFTLE1BQUlOLCtDQUFRLENBQUMsS0FBSztJQUMxQyxLQUFLLE1BQUVPLEtBQUksTUFBRUMsT0FBTyxNQUFJUiwrQ0FBUSxDQUFDLENBQUU7SUFFbkMsS0FBSyxDQUFDUyxTQUFTLE9BQVMsQ0FBQztRQUN2QkgsU0FBUyxDQUFDLElBQUk7SUFDaEIsQ0FBQztJQUVELEtBQUssQ0FBQ0ksUUFBUSxPQUFTLENBQUM7UUFDdEJKLFNBQVMsQ0FBQyxLQUFLO0lBQ2pCLENBQUM7SUFFRCxLQUFLLENBQUNLLFlBQVksT0FBUyxDQUFDO1FBQzFCTCxTQUFTLENBQUMsS0FBSztJQUNqQixDQUFDO0lBRUQsS0FBSyxDQUFDTSxjQUFjLElBQUlMLElBQVMsR0FBSyxDQUFDO1FBQ3JDTSxPQUFPLENBQUNDLEdBQUcsQ0FBQ1AsSUFBSTtRQUNoQkQsU0FBUyxDQUFDLEtBQUs7UUFDZkUsT0FBTyxDQUFDRCxJQUFJO0lBQ2QsQ0FBQztJQUVELE1BQU07O3dGQUVETCx3Q0FBTTtnQkFBQ2EsSUFBSSxFQUFDLENBQVM7Z0JBQUNDLE9BQU8sRUFBRVAsU0FBUzswQkFBRSxDQUUzQzs7Ozs7O3dGQUNDUSxDQUFHOzBCQUFFVixLQUFJLENBQUNXLE9BQU87Ozs7OztZQUVqQmIsTUFBTSxnRkFDSkosdUNBQUs7Z0JBQ0prQixLQUFLLEVBQUMsQ0FBYTtnQkFDbkJDLE9BQU8sRUFBRSxJQUFJO2dCQUNiQyxJQUFJLEVBQUVYLFFBQVE7Z0JBQ2RZLFFBQVEsRUFBRVgsWUFBWTtzR0FFckJSLDREQUFZO29CQUFDb0IsVUFBVSxFQUFFWCxjQUFjOzs7Ozs7Ozs7Ozs7O0FBY2xELENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcmVlYm9hcmRfZnJvbnRlbmQvLi9wYWdlcy8xNS1tb2RhbC1hZGRyZXNzL2luZGV4LnRzeD8xMTUwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBNb2RhbCwgQnV0dG9uIH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCBEYXVtUG9zdGNvZGUgZnJvbSBcInJlYWN0LWRhdW0tcG9zdGNvZGVcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTW9kYWxDdXN0b21QYWdlKCkge1xuICBjb25zdCBbaXNPcGVuLCBzZXRJc09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZGF0YSwgc2V0RGF0YV0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBzaG93TW9kYWwgPSAoKSA9PiB7XG4gICAgc2V0SXNPcGVuKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZU9rID0gKCkgPT4ge1xuICAgIHNldElzT3BlbihmYWxzZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2FuY2VsID0gKCkgPT4ge1xuICAgIHNldElzT3BlbihmYWxzZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ29tcGxldGUgPSAoZGF0YTogYW55KSA9PiB7XG4gICAgY29uc29sZS5sb2coZGF0YSk7XG4gICAgc2V0SXNPcGVuKGZhbHNlKTtcbiAgICBzZXREYXRhKGRhdGEpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxCdXR0b24gdHlwZT1cInByaW1hcnlcIiBvbkNsaWNrPXtzaG93TW9kYWx9PlxuICAgICAgICDrqqjri6zsl7TquLBcbiAgICAgIDwvQnV0dG9uPlxuICAgICAgPGRpdj57ZGF0YS5hZGRyZXNzfTwvZGl2PlxuICAgICAgey8qIOuqqOuLrCDsgq3soJwg7ZWY6rOgIOyDiOuhnCDrp4zrk5zripQg67Cp67KVICovfVxuICAgICAge2lzT3BlbiAmJiAoXG4gICAgICAgIDxNb2RhbFxuICAgICAgICAgIHRpdGxlPVwiQmFzaWMgTW9kYWxcIlxuICAgICAgICAgIHZpc2libGU9e3RydWV9XG4gICAgICAgICAgb25Paz17aGFuZGxlT2t9XG4gICAgICAgICAgb25DYW5jZWw9e2hhbmRsZUNhbmNlbH1cbiAgICAgICAgPlxuICAgICAgICAgIDxEYXVtUG9zdGNvZGUgb25Db21wbGV0ZT17aGFuZGxlQ29tcGxldGV9IC8+XG4gICAgICAgIDwvTW9kYWw+XG4gICAgICApfVxuICAgICAgey8qIOuqqOuLrCDsiKjqsrzri6TqsIAg64KY7YOA64KY6rKMIO2VmOuKlCDrsKnrspUgKi99XG4gICAgICB7LyogPE1vZGFsXG4gICAgICAgIHRpdGxlPVwiQmFzaWMgTW9kYWxcIlxuICAgICAgICB2aXNpYmxlPXtpc09wZW59IFxuICAgICAgICBvbk9rPXtoYW5kbGVPa31cbiAgICAgICAgb25DYW5jZWw9e2hhbmRsZUNhbmNlbH1cbiAgICAgID5cbiAgICAgICAgPERhdW1Qb3N0Y29kZSBvbkNvbXBsZXRlPXtoYW5kbGVDb21wbGV0ZX0gLz5cbiAgICAgIDwvTW9kYWw+ICovfVxuICAgIDwvPlxuICApO1xufVxuIl0sIm5hbWVzIjpbInVzZVN0YXRlIiwiTW9kYWwiLCJCdXR0b24iLCJEYXVtUG9zdGNvZGUiLCJNb2RhbEN1c3RvbVBhZ2UiLCJpc09wZW4iLCJzZXRJc09wZW4iLCJkYXRhIiwic2V0RGF0YSIsInNob3dNb2RhbCIsImhhbmRsZU9rIiwiaGFuZGxlQ2FuY2VsIiwiaGFuZGxlQ29tcGxldGUiLCJjb25zb2xlIiwibG9nIiwidHlwZSIsIm9uQ2xpY2siLCJkaXYiLCJhZGRyZXNzIiwidGl0bGUiLCJ2aXNpYmxlIiwib25PayIsIm9uQ2FuY2VsIiwib25Db21wbGV0ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/15-modal-address/index.tsx\n");

/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-daum-postcode":
/*!**************************************!*\
  !*** external "react-daum-postcode" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("react-daum-postcode");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/15-modal-address/index.tsx"));
module.exports = __webpack_exports__;

})();