"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/13-modal-address";
exports.ids = ["pages/13-modal-address"];
exports.modules = {

/***/ "./pages/13-modal-address/index.tsx":
/*!******************************************!*\
  !*** ./pages/13-modal-address/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ModalCustomPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ \"antd\");\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react_daum_postcode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-daum-postcode */ \"react-daum-postcode\");\n/* harmony import */ var react_daum_postcode__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_daum_postcode__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nfunction ModalCustomPage() {\n    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);\n    const handleOk = ()=>{\n        setIsOpen(false);\n    };\n    const handleCancel = ()=>{\n        setIsOpen(false);\n    };\n    const handleComplete = (data)=>{\n        console.log(data);\n        setIsOpen(false);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: isOpen && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__.Modal, {\n            title: \"Basic Modal\",\n            visible: isOpen,\n            onOk: handleOk,\n            onCancel: handleCancel,\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_daum_postcode__WEBPACK_IMPORTED_MODULE_3___default()), {\n                onComplete: handleComplete\n            }, void 0, false, {\n                fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/13-modal-address/index.tsx\",\n                lineNumber: 31,\n                columnNumber: 11\n            }, this)\n        }, void 0, false, {\n            fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/13-modal-address/index.tsx\",\n            lineNumber: 25,\n            columnNumber: 9\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xMy1tb2RhbC1hZGRyZXNzL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQWdDO0FBQ0k7QUFDVTtBQUUvQixRQUFRLENBQUNHLGVBQWUsR0FBRyxDQUFDO0lBQ3pDLEtBQUssTUFBRUMsTUFBTSxNQUFFQyxTQUFTLE1BQUlMLCtDQUFRLENBQUMsSUFBSTtJQUV6QyxLQUFLLENBQUNNLFFBQVEsT0FBUyxDQUFDO1FBQ3RCRCxTQUFTLENBQUMsS0FBSztJQUNqQixDQUFDO0lBRUQsS0FBSyxDQUFDRSxZQUFZLE9BQVMsQ0FBQztRQUMxQkYsU0FBUyxDQUFDLEtBQUs7SUFDakIsQ0FBQztJQUVELEtBQUssQ0FBQ0csY0FBYyxJQUFJQyxJQUFTLEdBQUssQ0FBQztRQUNyQ0MsT0FBTyxDQUFDQyxHQUFHLENBQUNGLElBQUk7UUFDaEJKLFNBQVMsQ0FBQyxLQUFLO0lBQ2pCLENBQUM7SUFFRCxNQUFNO2tCQUdERCxNQUFNLGdGQUNKSCx1Q0FBSztZQUNKVyxLQUFLLEVBQUMsQ0FBYTtZQUNuQkMsT0FBTyxFQUFFVCxNQUFNO1lBQ2ZVLElBQUksRUFBRVIsUUFBUTtZQUNkUyxRQUFRLEVBQUVSLFlBQVk7a0dBRXJCTCw0REFBWTtnQkFBQ2MsVUFBVSxFQUFFUixjQUFjOzs7Ozs7Ozs7Ozs7QUFLbEQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2ZyZWVib2FyZF9mcm9udGVuZC8uL3BhZ2VzLzEzLW1vZGFsLWFkZHJlc3MvaW5kZXgudHN4PzJmYmIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE1vZGFsLCBCdXR0b24gfSBmcm9tIFwiYW50ZFwiO1xuaW1wb3J0IERhdW1Qb3N0Y29kZSBmcm9tIFwicmVhY3QtZGF1bS1wb3N0Y29kZVwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNb2RhbEN1c3RvbVBhZ2UoKSB7XG4gIGNvbnN0IFtpc09wZW4sIHNldElzT3Blbl0gPSB1c2VTdGF0ZSh0cnVlKTtcblxuICBjb25zdCBoYW5kbGVPayA9ICgpID0+IHtcbiAgICBzZXRJc09wZW4oZmFsc2UpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNhbmNlbCA9ICgpID0+IHtcbiAgICBzZXRJc09wZW4oZmFsc2UpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNvbXBsZXRlID0gKGRhdGE6IGFueSkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuICAgIHNldElzT3BlbihmYWxzZSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgey8qIOuqqOuLrCDsgq3soJwg7ZWY6rOgIOyDiOuhnCDrp4zrk5zripQg67Cp67KVICovfVxuICAgICAge2lzT3BlbiAmJiAoXG4gICAgICAgIDxNb2RhbFxuICAgICAgICAgIHRpdGxlPVwiQmFzaWMgTW9kYWxcIlxuICAgICAgICAgIHZpc2libGU9e2lzT3Blbn1cbiAgICAgICAgICBvbk9rPXtoYW5kbGVPa31cbiAgICAgICAgICBvbkNhbmNlbD17aGFuZGxlQ2FuY2VsfVxuICAgICAgICA+XG4gICAgICAgICAgPERhdW1Qb3N0Y29kZSBvbkNvbXBsZXRlPXtoYW5kbGVDb21wbGV0ZX0gLz5cbiAgICAgICAgPC9Nb2RhbD5cbiAgICAgICl9XG4gICAgPC8+XG4gICk7XG59XG4iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJNb2RhbCIsIkRhdW1Qb3N0Y29kZSIsIk1vZGFsQ3VzdG9tUGFnZSIsImlzT3BlbiIsInNldElzT3BlbiIsImhhbmRsZU9rIiwiaGFuZGxlQ2FuY2VsIiwiaGFuZGxlQ29tcGxldGUiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsInRpdGxlIiwidmlzaWJsZSIsIm9uT2siLCJvbkNhbmNlbCIsIm9uQ29tcGxldGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/13-modal-address/index.tsx\n");

/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-daum-postcode":
/*!**************************************!*\
  !*** external "react-daum-postcode" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("react-daum-postcode");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/13-modal-address/index.tsx"));
module.exports = __webpack_exports__;

})();