"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/27-02-login-success";
exports.ids = ["pages/27-02-login-success"];
exports.modules = {

/***/ "./pages/27-02-login-success/index.tsx":
/*!*********************************************!*\
  !*** ./pages/27-02-login-success/index.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginSuccessPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../src/commons/store */ \"./src/commons/store/index.ts\");\n\n\n\n\n\n\nconst FETCH_USER_LOGGED_IN = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  query fetchUserLoggedIn {\n    fetchUserLoggedIn {\n      email\n      name\n    }\n  }\n`;\nfunction LoginSuccessPage() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const [accessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_5__.accessTokenState);\n    const { data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useQuery)(FETCH_USER_LOGGED_IN);\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        if (!accessToken) {\n            router.push(\"/27-01-login\");\n            alert(\"로그인을 먼저 해주세요\");\n        }\n    }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            data === null || data === void 0 ? void 0 : data.fetchUserLoggedIn.name,\n            \"님 환영합니다!\"\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/27-02-login-success/index.tsx\",\n        lineNumber: 28,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yNy0wMi1sb2dpbi1zdWNjZXNzL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQThDO0FBQ1A7QUFDTjtBQUNNO0FBQ21CO0FBRTFELEtBQUssQ0FBQ00sb0JBQW9CLEdBQUdMLCtDQUFHLENBQUM7Ozs7Ozs7QUFPakM7QUFFZSxRQUFRLENBQUNNLGdCQUFnQixHQUFHLENBQUM7SUFDMUMsS0FBSyxDQUFDQyxNQUFNLEdBQUdOLHNEQUFTO0lBQ3hCLEtBQUssRUFBRU8sV0FBVyxJQUFJTCxzREFBYyxDQUFDQyxnRUFBZ0I7SUFDckQsS0FBSyxDQUFDLENBQUMsQ0FBQ0ssSUFBSSxFQUFDLENBQUMsR0FBR1Ysd0RBQVEsQ0FBQ00sb0JBQW9CO0lBRTlDSCxnREFBUyxLQUFPLENBQUM7UUFDZixFQUFFLEdBQUdNLFdBQVcsRUFBRSxDQUFDO1lBQ2pCRCxNQUFNLENBQUNHLElBQUksQ0FBQyxDQUFjO1lBQzFCQyxLQUFLLENBQUMsQ0FBYztRQUNGLENBQW5CO0lBQ0gsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUVMLE1BQU0sNkVBQUVDLENBQUc7O1lBQUVILElBQUksYUFBSkEsSUFBSSxLQUFKQSxJQUFJLENBQUpBLENBQXVCLEdBQXZCQSxJQUFJLENBQUpBLENBQXVCLEdBQXZCQSxJQUFJLENBQUVJLGlCQUFpQixDQUFDQyxJQUFJO1lBQUMsQ0FBUTs7Ozs7OztBQUNwRCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJlZWJvYXJkX2Zyb250ZW5kLy4vcGFnZXMvMjctMDItbG9naW4tc3VjY2Vzcy9pbmRleC50c3g/NGQwMSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSwgZ3FsIH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlUmVjb2lsU3RhdGUgfSBmcm9tIFwicmVjb2lsXCI7XG5pbXBvcnQgeyBhY2Nlc3NUb2tlblN0YXRlIH0gZnJvbSBcIi4uLy4uL3NyYy9jb21tb25zL3N0b3JlXCI7XG5cbmNvbnN0IEZFVENIX1VTRVJfTE9HR0VEX0lOID0gZ3FsYFxuICBxdWVyeSBmZXRjaFVzZXJMb2dnZWRJbiB7XG4gICAgZmV0Y2hVc2VyTG9nZ2VkSW4ge1xuICAgICAgZW1haWxcbiAgICAgIG5hbWVcbiAgICB9XG4gIH1cbmA7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luU3VjY2Vzc1BhZ2UoKSB7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuICBjb25zdCBbYWNjZXNzVG9rZW5dID0gdXNlUmVjb2lsU3RhdGUoYWNjZXNzVG9rZW5TdGF0ZSk7XG4gIGNvbnN0IHsgZGF0YSB9ID0gdXNlUXVlcnkoRkVUQ0hfVVNFUl9MT0dHRURfSU4pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFhY2Nlc3NUb2tlbikge1xuICAgICAgcm91dGVyLnB1c2goXCIvMjctMDEtbG9naW5cIik7XG4gICAgICBhbGVydChcIuuhnOq3uOyduOydhCDrqLzsoIAg7ZW07KO87IS47JqUXCIpO1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIHJldHVybiA8ZGl2PntkYXRhPy5mZXRjaFVzZXJMb2dnZWRJbi5uYW1lfeuLmCDtmZjsmIHtlanri4jri6QhPC9kaXY+O1xufVxuIl0sIm5hbWVzIjpbInVzZVF1ZXJ5IiwiZ3FsIiwidXNlUm91dGVyIiwidXNlRWZmZWN0IiwidXNlUmVjb2lsU3RhdGUiLCJhY2Nlc3NUb2tlblN0YXRlIiwiRkVUQ0hfVVNFUl9MT0dHRURfSU4iLCJMb2dpblN1Y2Nlc3NQYWdlIiwicm91dGVyIiwiYWNjZXNzVG9rZW4iLCJkYXRhIiwicHVzaCIsImFsZXJ0IiwiZGl2IiwiZmV0Y2hVc2VyTG9nZ2VkSW4iLCJuYW1lIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/27-02-login-success/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\n// 글로벌 스테이트\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"isEditState\",\n    default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"iaccessTokenState\",\n    default: \"\"\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQTZCO0FBRTdCLEVBQVc7QUFDSixLQUFLLENBQUNDLFdBQVcsR0FBR0QsNENBQUksQ0FBQyxDQUFDO0lBQy9CRSxHQUFHLEVBQUUsQ0FBYTtJQUNsQkMsT0FBTyxFQUFFLEtBQUs7QUFDaEIsQ0FBQztBQUNNLEtBQUssQ0FBQ0MsZ0JBQWdCLEdBQUdKLDRDQUFJLENBQUMsQ0FBQztJQUNwQ0UsR0FBRyxFQUFFLENBQW1CO0lBQ3hCQyxPQUFPLEVBQUUsQ0FBRTtBQUNiLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcmVlYm9hcmRfZnJvbnRlbmQvLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cz8zY2JmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20gfSBmcm9tIFwicmVjb2lsXCI7XG5cbi8vIOq4gOuhnOuyjCDsiqTthYzsnbTtirhcbmV4cG9ydCBjb25zdCBpc0VkaXRTdGF0ZSA9IGF0b20oe1xuICBrZXk6IFwiaXNFZGl0U3RhdGVcIixcbiAgZGVmYXVsdDogZmFsc2UsXG59KTtcbmV4cG9ydCBjb25zdCBhY2Nlc3NUb2tlblN0YXRlID0gYXRvbSh7XG4gIGtleTogXCJpYWNjZXNzVG9rZW5TdGF0ZVwiLFxuICBkZWZhdWx0OiBcIlwiLFxufSk7XG4iXSwibmFtZXMiOlsiYXRvbSIsImlzRWRpdFN0YXRlIiwia2V5IiwiZGVmYXVsdCIsImFjY2Vzc1Rva2VuU3RhdGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/27-02-login-success/index.tsx"));
module.exports = __webpack_exports__;

})();