"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/14-modal-alert";
exports.ids = ["pages/14-modal-alert"];
exports.modules = {

/***/ "./pages/14-modal-alert/index.tsx":
/*!****************************************!*\
  !*** ./pages/14-modal-alert/index.tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ModalAlertPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ \"antd\");\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction ModalAlertPage() {\n    const onClickSuccessButton = ()=>{\n        antd__WEBPACK_IMPORTED_MODULE_1__.Modal.success({\n            content: \"게시물 등록에 성공했습니다\"\n        });\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n            onClick: onClickSuccessButton,\n            children: \"모달 열기\"\n        }, void 0, false, {\n            fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/14-modal-alert/index.tsx\",\n            lineNumber: 10,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/atoosisss_/Desktop/code-camp/quiz/pages/14-modal-alert/index.tsx\",\n        lineNumber: 9,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNC1tb2RhbC1hbGVydC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQTRCO0FBRWIsUUFBUSxDQUFDQyxjQUFjLEdBQUcsQ0FBQztJQUN4QyxLQUFLLENBQUNDLG9CQUFvQixPQUFTLENBQUM7UUFDbENGLCtDQUFhLENBQUMsQ0FBQztZQUFDSSxPQUFPLEVBQUUsQ0FBZ0I7UUFBeUIsQ0FBQztJQUM3QyxDQUF2QjtJQUVELE1BQU0sNkVBQ0hDLENBQUc7OEZBQ0RDLENBQU07WUFBQ0MsT0FBTyxFQUFFTCxvQkFBb0I7c0JBQUUsQ0FBSzs7Ozs7Ozs7Ozs7QUFHbEQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2ZyZWVib2FyZF9mcm9udGVuZC8uL3BhZ2VzLzE0LW1vZGFsLWFsZXJ0L2luZGV4LnRzeD8wNzAzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vZGFsIH0gZnJvbSBcImFudGRcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTW9kYWxBbGVydFBhZ2UoKSB7XG4gIGNvbnN0IG9uQ2xpY2tTdWNjZXNzQnV0dG9uID0gKCkgPT4ge1xuICAgIE1vZGFsLnN1Y2Nlc3MoeyBjb250ZW50OiBcIuqyjOyLnOusvCDrk7HroZ3sl5Ag7ISx6rO17ZaI7Iq164uI64ukXCIgfSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrU3VjY2Vzc0J1dHRvbn0+66qo64usIOyXtOq4sDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm5hbWVzIjpbIk1vZGFsIiwiTW9kYWxBbGVydFBhZ2UiLCJvbkNsaWNrU3VjY2Vzc0J1dHRvbiIsInN1Y2Nlc3MiLCJjb250ZW50IiwiZGl2IiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/14-modal-alert/index.tsx\n");

/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/14-modal-alert/index.tsx"));
module.exports = __webpack_exports__;

})();