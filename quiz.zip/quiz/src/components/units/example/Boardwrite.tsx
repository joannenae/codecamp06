import BoardEdit from "../../../../pages/example/recoil/Boardedit";

export default function BoardWrite() {
  return <BoardEdit />;
}

// container
