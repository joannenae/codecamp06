import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 50px;
  background-color: green;
`;

export default function Layoutfooter() {
  return <Wrapper>푸터 영역</Wrapper>;
}
