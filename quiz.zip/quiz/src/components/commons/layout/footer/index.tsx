import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 50px;
  background-color: black;
`;

export default function Layoutfooter() {
  return <Wrapper>푸터 영역</Wrapper>;
}
