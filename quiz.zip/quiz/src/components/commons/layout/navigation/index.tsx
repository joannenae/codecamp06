import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 50px;
  background-color: orange;
`;

export default function LayoutNavigation() {
  return <Wrapper>navigation</Wrapper>;
}
