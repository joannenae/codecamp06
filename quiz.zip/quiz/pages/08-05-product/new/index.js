// 등록하기 페이지

import ProductWrite from "../../../src/components/units/product/08-product-write/ProductWrite.container"

export default function ProductNewPage(){
    return <ProductWrite isEdit={false} />
}