export default function Presenter(aaa: any) {
  return (
    <div>
      {aaa.child}는 {aaa.age}살 입니다.
    </div>
  );
}
