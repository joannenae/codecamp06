export default function TwoPage() {
  return <div>바디영역</div>;
}
