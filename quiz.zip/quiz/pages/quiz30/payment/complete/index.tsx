export default function CompletePage() {
  return <div>축하해</div>;
}
