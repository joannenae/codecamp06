export default function OnePage() {
  return <div>바디영역</div>;
}
