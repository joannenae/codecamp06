export default function ThreePage() {
  return <div>바디영역</div>;
}
